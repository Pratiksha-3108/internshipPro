from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np

class Dataset(BaseModel):
    data: list

app = FastAPI()

@app.post("/predict")
async def predict(ds: Dataset):
    arr = np.array(ds.data)
    return {"trend": float(arr.mean()), "anomaly": float(arr.std())}
