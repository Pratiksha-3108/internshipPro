const Graph = require('../models/Graph');

exports.createGraph = async (req, res) => {
  try {
    const graph = await Graph.create(req.body);
    res.status(201).json(graph);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getGraph = async (req, res) => {
  try {
    const graph = await Graph.findById(req.params.id);
    if (!graph) return res.status(404).json({ message: 'Not found' });
    res.json(graph);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
