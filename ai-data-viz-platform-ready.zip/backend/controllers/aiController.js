const axios = require('axios');
const AIInsight = require('../models/AIInsight');

exports.analyze = async (req, res) => {
  try {
    const insights = await axios.post(process.env.AI_SERVICE_URL, { data: req.body.data });
    const record = await AIInsight.create({
      datasetId: req.params.datasetId,
      insightsData: insights.data
    });
    res.json(record);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
