const mongoose = require('mongoose');

const aiInsightSchema = new mongoose.Schema({
  datasetId: { type: mongoose.Schema.Types.ObjectId, ref: 'Dataset', required: true },
  insightsData: { type: Object, required: true },
}, { timestamps: true });

module.exports = mongoose.model('AIInsight', aiInsightSchema);
