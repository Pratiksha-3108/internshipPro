const mongoose = require('mongoose');

const graphSchema = new mongoose.Schema({
  datasetId: { type: mongoose.Schema.Types.ObjectId, ref: 'Dataset', required: true },
  graphType: { type: String, required: true },
  graphConfig: { type: Object, required: true },
}, { timestamps: true });

module.exports = mongoose.model('Graph', graphSchema);
