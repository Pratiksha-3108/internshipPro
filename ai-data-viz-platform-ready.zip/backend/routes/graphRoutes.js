const express = require('express');
const { createGraph, getGraph } = require('../controllers/graphController');
const router = express.Router();

router.post('/create', createGraph);
router.get('/:id', getGraph);

module.exports = router;
