# AI Data Visualization & Analytics Platform

Run `docker-compose up --build`